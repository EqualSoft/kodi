# Video plugin for Filelist.ro 

This is a video plugin for the Filelist.ro site using the API provided.

How it works:

First set username and passkey in settings. Optional an TMDB api key can be set to get movie posters & fanart.

To watch directly the Elementum addon must be installed, it will not be installed with this plugin, as it is not required.
Another option is to save the torrent in a directory and a torrent client will pick it up.

Requirements:

Simple cache addon is needed, it should be installed with the plugin as it is required. 
If not, it can be found here: https://github.com/kodi-community-addons/script.module.simplecache

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
